
import React, { useEffect, useRef } from 'react';

export const ThreeScene = () => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<any>(null);
  const animationRef = useRef<number>();

  useEffect(() => {
    if (!mountRef.current) return;

    // Dynamically import Three.js
    const loadThreeJS = async () => {
      const THREE = await import('three');
      
      // Scene setup
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
      const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
      
      renderer.setSize(window.innerWidth, window.innerHeight);
      renderer.setClearColor(0x000000, 0);
      mountRef.current?.appendChild(renderer.domElement);

      // Lighting
      const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
      scene.add(ambientLight);

      const pointLight = new THREE.PointLight(0x00ffff, 1, 100);
      pointLight.position.set(10, 10, 10);
      scene.add(pointLight);

      const pointLight2 = new THREE.PointLight(0xff00ff, 1, 100);
      pointLight2.position.set(-10, -10, 10);
      scene.add(pointLight2);

      // Create multiple geometric shapes
      const shapes: any[] = [];

      // Main rotating cube
      const cubeGeometry = new THREE.BoxGeometry(2, 2, 2);
      const cubeMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x00ffff,
        transparent: true,
        opacity: 0.8,
        wireframe: false
      });
      const cube = new THREE.Mesh(cubeGeometry, cubeMaterial);
      cube.position.set(0, 0, 0);
      scene.add(cube);
      shapes.push(cube);

      // Wireframe cube
      const wireframeMaterial = new THREE.MeshBasicMaterial({ 
        color: 0xff00ff,
        wireframe: true,
        transparent: true,
        opacity: 0.3
      });
      const wireframeCube = new THREE.Mesh(cubeGeometry, wireframeMaterial);
      wireframeCube.scale.set(1.2, 1.2, 1.2);
      scene.add(wireframeCube);
      shapes.push(wireframeCube);

      // Floating spheres
      for (let i = 0; i < 5; i++) {
        const sphereGeometry = new THREE.SphereGeometry(0.3, 32, 32);
        const sphereMaterial = new THREE.MeshPhongMaterial({ 
          color: Math.random() * 0xffffff,
          transparent: true,
          opacity: 0.6
        });
        const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
        
        sphere.position.set(
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 20
        );
        
        scene.add(sphere);
        shapes.push(sphere);
      }

      camera.position.z = 8;

      // Mouse interaction
      let mouseX = 0;
      let mouseY = 0;

      const handleMouseMove = (event: MouseEvent) => {
        mouseX = (event.clientX / window.innerWidth) * 2 - 1;
        mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
      };

      window.addEventListener('mousemove', handleMouseMove);

      // Animation loop
      const animate = () => {
        animationRef.current = requestAnimationFrame(animate);

        // Rotate main shapes
        cube.rotation.x += 0.005;
        cube.rotation.y += 0.01;
        
        wireframeCube.rotation.x -= 0.003;
        wireframeCube.rotation.y -= 0.007;

        // Animate floating spheres
        shapes.slice(2).forEach((sphere, index) => {
          sphere.rotation.x += 0.01 * (index + 1);
          sphere.rotation.y += 0.005 * (index + 1);
          sphere.position.y += Math.sin(Date.now() * 0.001 + index) * 0.01;
        });

        // Mouse interaction
        cube.rotation.y += mouseX * 0.01;
        cube.rotation.x += mouseY * 0.01;

        // Camera gentle movement
        camera.position.x += (mouseX * 2 - camera.position.x) * 0.05;
        camera.position.y += (-mouseY * 2 - camera.position.y) * 0.05;

        renderer.render(scene, camera);
      };

      animate();

      // Handle resize
      const handleResize = () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
      };

      window.addEventListener('resize', handleResize);

      // Store references for cleanup
      sceneRef.current = {
        scene,
        renderer,
        camera,
        cleanup: () => {
          window.removeEventListener('mousemove', handleMouseMove);
          window.removeEventListener('resize', handleResize);
          if (animationRef.current) {
            cancelAnimationFrame(animationRef.current);
          }
          if (mountRef.current && renderer.domElement) {
            mountRef.current.removeChild(renderer.domElement);
          }
          renderer.dispose();
        }
      };
    };

    loadThreeJS();

    return () => {
      if (sceneRef.current) {
        sceneRef.current.cleanup();
      }
    };
  }, []);

  return <div ref={mountRef} className="absolute inset-0" />;
};
