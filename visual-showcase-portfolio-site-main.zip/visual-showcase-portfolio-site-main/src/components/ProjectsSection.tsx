
import React from 'react';
import { ProjectCard } from './ProjectCard';

export const ProjectsSection = () => {
  const projects = [
    {
      title: "E-Commerce Platform",
      description: "A full-stack e-commerce solution built with React, Node.js, and PostgreSQL. Features include real-time inventory management, payment processing, and advanced analytics dashboard.",
      image: "/placeholder.svg",
      technologies: ["React", "Node.js", "PostgreSQL", "Stripe"],
      githubUrl: "https://github.com/example/ecommerce",
      liveUrl: "https://ecommerce-demo.vercel.app"
    },
    {
      title: "3D Portfolio Showcase",
      description: "An interactive 3D portfolio website featuring Three.js animations, WebGL shaders, and responsive design. Showcases modern web technologies and creative visual effects.",
      image: "/placeholder.svg",
      technologies: ["Three.js", "React", "WebGL", "GSAP"],
      githubUrl: "https://github.com/example/3d-portfolio",
      liveUrl: "https://3d-portfolio-demo.vercel.app"
    },
    {
      title: "AI Chat Application",
      description: "Real-time chat application with AI-powered responses, built using React, Socket.io, and OpenAI API. Features include message encryption, file sharing, and smart suggestions.",
      image: "/placeholder.svg",
      technologies: ["React", "Socket.io", "OpenAI", "MongoDB"],
      githubUrl: "https://github.com/example/ai-chat",
      liveUrl: "https://ai-chat-demo.vercel.app"
    }
  ];

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            Featured Projects
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-400 to-blue-400 mx-auto mb-6"></div>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Here are some of my recent projects that showcase my skills in modern web development
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={index} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};
