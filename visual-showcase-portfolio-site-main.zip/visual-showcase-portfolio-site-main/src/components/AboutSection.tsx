
import React from 'react';

export const AboutSection = () => {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            About Me
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-400 to-blue-400 mx-auto"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Profile Image */}
          <div className="text-center md:text-left">
            <div className="relative inline-block">
              <div className="w-80 h-80 mx-auto md:mx-0 rounded-full bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 p-1">
                <div className="w-full h-full rounded-full bg-gray-800 flex items-center justify-center">
                  <div className="w-72 h-72 rounded-full bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center text-6xl font-bold text-white">
                    AJ
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center animate-pulse">
                <span className="text-white text-2xl">👋</span>
              </div>
            </div>
          </div>

          {/* About Content */}
          <div className="space-y-6">
            <div className="prose prose-lg text-gray-300">
              <p className="text-xl leading-relaxed">
                I'm a passionate <span className="text-cyan-400 font-semibold">Full Stack Developer</span> with 
                over 5 years of experience creating digital solutions that bridge the gap between design and technology.
              </p>
              <p className="text-lg leading-relaxed">
                My expertise spans across modern web technologies including React, Node.js, Python, and cloud platforms. 
                I specialize in building scalable applications with exceptional user experiences, always staying current 
                with the latest industry trends and best practices.
              </p>
              <p className="text-lg leading-relaxed">
                When I'm not coding, you'll find me exploring new technologies, contributing to open-source projects, 
                or sharing knowledge with the developer community through blog posts and mentoring.
              </p>
            </div>

            {/* Skills */}
            <div className="grid grid-cols-2 gap-4 mt-8">
              {[
                'React & Next.js',
                'Node.js & Express',
                'Python & Django',
                'TypeScript',
                'AWS & Cloud',
                'UI/UX Design',
                'Three.js & WebGL',
                'Database Design'
              ].map((skill, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                  <span className="text-gray-300">{skill}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
